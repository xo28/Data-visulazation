import colors from "../colors.js";

export default colors("e41a1c377eb84daf4a984ea3ff7f00ffff33a65628f781bf999999");
